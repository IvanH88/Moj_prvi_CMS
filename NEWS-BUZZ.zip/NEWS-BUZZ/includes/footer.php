 <footer class="foo">
            <div class="row">
                <div class="col-lg-12">
                    <p style="text-align:center; font-family: 'Monotype Corsiva'; font-size:17px;"><i class="material-icons" style="color: brown;"></i> U Virovitici 2023. godine <b ></b></p>
                </div>
            </div>
   </footer>