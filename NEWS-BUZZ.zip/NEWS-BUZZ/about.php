<?php include 'includes/header.php';?>
        <!-- Navigation Bar -->
   <?php include 'includes/navbar.php';?>
        <!-- Navigation Bar -->

    <div class="container">
        <div class="row">
	        <!-- Page Content -->
	        <div class="col-md-8">
            <h1 class="page-header">O | nama </h1>
            Dobrodošli!
            <br>
            Ova aplikacija je primjer jednostavnog ''Content Management'' sustava ili CMS-a.<br>
            
            <br><br><br>




           
           Glavne mogućnosti:
           <br><br>
           # Mogućnost dodavanja više korisnika <br>
           # Administratori imaju mogućnosti dodavanja sadržaja i korisnika <br>
           # Različite dodatne mogućnosti kao što su dodavanje, izmjena i promjena sadržaja <br>
           # Mogućnosti izmjene profila korisnika <br>
           # Mogućnosti ulogiravanja korisnika kao i dodavanje novih korisnika <br>
           <br>
            
           <br><br><br>

           Korišteni alati za izradu projekta: 
           <br><br>
           #Front-End:  HTML, CSS <br>
           #Back-End:   PHP       <br>
           #Baza podataka:   MySQL     <br>
           <br><br><br>

           Projekt razvio: <br><br>
           Ime: Ivan Hečimović <br>
           E-pošta: ivan0701988@gmail.com <br>
           <br>
           <br>
           <br>



        </div>

             <div class="col-md-4">

               <?php include 'includes/sidebar.php';
?><!-- Footer -->
</div>
</div>
</div>
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>

</body>
</html>